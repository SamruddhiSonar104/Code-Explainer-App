export interface PromptTemplate {
  id: string;
  name: string;
  description: string;
  template: string;
}

export const promptTemplates = {
  explain: {
    id: "explain",
    name: "Explain",
    description: "Explain what this code does",
    template: "Explain this code like I'm a beginner programmer:",
  },
  debug: {
    id: "debug",
    name: "Debug",
    description: "Find bugs and issues in the code",
    template: "Find potential bugs or issues in this code:",
  },
  document: {
    id: "document",
    name: "Document",
    description: "Generate documentation for the code",
    template: "Generate documentation for this code:",
  },
  interview: {
    id: "interview",
    name: "Interview",
    description: "Generate interview questions about this code",
    template: "Ask me interview questions about this code:",
  },
  improve: {
    id: "improve",
    name: "Improve",
    description: "Suggest code improvements",
    template: "Suggest improvements for this code:",
  },
};

export function getPromptTemplate(mode: string): string {
  const template = promptTemplates[mode as keyof typeof promptTemplates];
  return template ? template.template : promptTemplates.explain.template;
}
