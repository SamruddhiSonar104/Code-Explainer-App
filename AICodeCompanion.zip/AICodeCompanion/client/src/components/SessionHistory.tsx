import React from "react";
import { History } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";

interface SessionHistoryProps {
  history: History[];
  onSelectItem: (item: History) => void;
}

export default function SessionHistory({ history, onSelectItem }: SessionHistoryProps) {
  return (
    <>
      <h2 className="text-xs font-semibold text-neutral-500 dark:text-neutral-400 uppercase tracking-wider mb-2">Recent History</h2>
      <div className="space-y-2 mb-4">
        {history.length === 0 ? (
          <div className="text-sm text-neutral-500 dark:text-neutral-400 italic px-2 py-3">
            No recent activity
          </div>
        ) : (
          history.map((item) => (
            <div
              key={item.id}
              onClick={() => onSelectItem(item)}
              className="p-2 rounded-md cursor-pointer hover:bg-neutral-100 dark:hover:bg-neutral-800"
            >
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center">
                  <span
                    className={`text-xs font-medium px-2 py-0.5 rounded ${
                      item.mode === "explain"
                        ? "bg-primary-100 text-primary-700 dark:bg-primary-900/30 dark:text-primary-300"
                        : item.mode === "debug"
                        ? "bg-secondary-100 text-secondary-700 dark:bg-secondary-900/30 dark:text-secondary-300"
                        : item.mode === "document"
                        ? "bg-accent-100 text-accent-700 dark:bg-accent-900/30 dark:text-accent-300"
                        : item.mode === "improve"
                        ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300"
                        : "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300"
                    }`}
                  >
                    {item.mode.charAt(0).toUpperCase() + item.mode.slice(1)}
                  </span>
                  <span className="ml-2 text-xs text-neutral-500 dark:text-neutral-400">
                    {formatDistanceToNow(new Date(item.createdAt), { addSuffix: true })}
                  </span>
                </div>
              </div>
              <div className="text-sm font-mono text-neutral-800 dark:text-neutral-300 truncate">
                {item.snippet.split("\n")[0]}
                {item.snippet.split("\n").length > 1 ? "..." : ""}
              </div>
            </div>
          ))
        )}
      </div>
    </>
  );
}
