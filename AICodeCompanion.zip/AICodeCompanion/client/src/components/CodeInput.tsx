import { useState, useEffect } from "react";
import CodeLanguageSelector from "./CodeLanguageSelector";
import { useLanguages } from "@/lib/languages";
import AnalysisModeSelector from "./AnalysisModeSelector";
import { Button } from "./ui/button";
import { useTheme } from "./ThemeProvider";

interface CodeInputProps {
  codeInput: string;
  setCodeInput: (code: string) => void;
  selectedLanguage: string;
  setSelectedLanguage: (lang: string) => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onSubmit: () => void;
  isLoading: boolean;
}

export default function CodeInput({
  codeInput,
  setCodeInput,
  selectedLanguage,
  setSelectedLanguage,
  activeTab,
  setActiveTab,
  onSubmit,
  isLoading
}: CodeInputProps) {
  const { languages } = useLanguages();
  const { theme } = useTheme();
  const [headerGradient, setHeaderGradient] = useState<string>("bg-gradient-to-r from-blue-500 to-purple-500");
  const [showCodeLengthWarning, setShowCodeLengthWarning] = useState(false);
  
  // Code length constants
  const MAX_RECOMMENDED_LENGTH = 8000;
  const WARNING_THRESHOLD = 6000;
  
  // Monitor code length and show warning if needed
  useEffect(() => {
    if (codeInput.length > WARNING_THRESHOLD) {
      setShowCodeLengthWarning(true);
    } else {
      setShowCodeLengthWarning(false);
    }
  }, [codeInput]);
  
  // Change header gradient based on active tab
  useEffect(() => {
    switch(activeTab) {
      case "explain":
        setHeaderGradient("bg-gradient-to-r from-blue-500 to-indigo-600");
        break;
      case "debug":
        setHeaderGradient("bg-gradient-to-r from-purple-500 to-pink-500");
        break;
      case "document":
        setHeaderGradient("bg-gradient-to-r from-teal-400 to-emerald-500");
        break;
      case "interview":
        setHeaderGradient("bg-gradient-to-r from-amber-400 to-orange-500");
        break;
      case "improve":
        setHeaderGradient("bg-gradient-to-r from-emerald-400 to-green-500");
        break;
      default:
        setHeaderGradient("bg-gradient-to-r from-blue-500 to-purple-500");
    }
  }, [activeTab]);
  
  const handleClearCode = () => {
    setCodeInput("");
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(codeInput);
  };
  
  // Calculate percentage of max recommended length
  const getCodeLengthPercentage = () => {
    return Math.min(100, Math.round((codeInput.length / MAX_RECOMMENDED_LENGTH) * 100));
  };
  
  // Get appropriate color for the code length indicator
  const getCodeLengthColor = () => {
    const percentage = getCodeLengthPercentage();
    if (percentage < 50) return "bg-green-500";
    if (percentage < 75) return "bg-yellow-500";
    if (percentage < 90) return "bg-orange-500";
    return "bg-red-500";
  };

  return (
    <div className="w-full md:w-1/2 h-full flex flex-col border-r border-neutral-200 dark:border-neutral-700">
      {/* Colorful header based on active tab */}
      <div className={`flex items-center justify-between px-4 py-3 ${headerGradient} text-white border-b border-neutral-200 dark:border-neutral-700`}>
        <div className="font-medium">Code Input</div>
        <CodeLanguageSelector 
          selectedLanguage={selectedLanguage}
          setSelectedLanguage={setSelectedLanguage}
          languages={languages}
        />
      </div>
      
      <div className="flex-1 overflow-hidden flex flex-col">
        <div className="flex-1 overflow-auto p-4 bg-white/50 dark:bg-neutral-800/50 backdrop-blur-sm">
          {/* Action buttons */}
          <div className="flex justify-end mb-2 space-x-2">
            <button
              onClick={handleClearCode}
              className={`p-1.5 rounded-md bg-white dark:bg-neutral-700 shadow-sm hover:shadow text-red-500 hover:text-red-600 dark:text-red-400 dark:hover:text-red-300 transition-all ${
                !codeInput.trim() ? "opacity-50 cursor-not-allowed" : "cursor-pointer"
              }`}
              disabled={!codeInput.trim()}
              title="Clear code"
            >
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-4 h-4">
                <path strokeLinecap="round" strokeLinejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
              </svg>
            </button>
            <button
              onClick={handleCopyCode}
              className={`p-1.5 rounded-md bg-white dark:bg-neutral-700 shadow-sm hover:shadow text-blue-500 hover:text-blue-600 dark:text-blue-400 dark:hover:text-blue-300 transition-all ${
                !codeInput.trim() ? "opacity-50 cursor-not-allowed" : "cursor-pointer"
              }`}
              disabled={!codeInput.trim()}
              title="Copy code"
            >
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-4 h-4">
                <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 17.25v3.375c0 .621-.504 1.125-1.125 1.125h-9.75a1.125 1.125 0 0 1-1.125-1.125V7.875c0-.621.504-1.125 1.125-1.125H6.75a9.06 9.06 0 0 1 1.5.124m7.5 10.376h3.375c.621 0 1.125-.504 1.125-1.125V11.25c0-4.46-3.243-8.161-7.5-8.876a9.06 9.06 0 0 0-1.5-.124H9.375c-.621 0-1.125.504-1.125 1.125v3.5m7.5 10.375H9.375a1.125 1.125 0 0 1-1.125-1.125v-9.25m12 6.625v-1.875a3.375 3.375 0 0 0-3.375-3.375h-1.5a1.125 1.125 0 0 1-1.125-1.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H9.75" />
              </svg>
            </button>
          </div>
          
          {/* Code editor - enhanced with colorful border */}
          <textarea
            value={codeInput}
            onChange={(e) => setCodeInput(e.target.value)}
            placeholder="// Paste or type your code here..."
            className={`w-full h-[calc(100%-2rem)] bg-white dark:bg-neutral-900 border-2 ${
              activeTab === "explain" ? "border-blue-500 dark:border-blue-600" :
              activeTab === "debug" ? "border-purple-500 dark:border-purple-600" :
              activeTab === "document" ? "border-teal-500 dark:border-teal-600" :
              activeTab === "interview" ? "border-amber-500 dark:border-amber-600" :
              "border-emerald-500 dark:border-emerald-600"
            } rounded-md p-4 font-mono text-sm text-neutral-800 dark:text-neutral-200 focus:outline-none focus:shadow-lg shadow-md transition-shadow duration-200 resize-none`}
          ></textarea>
        </div>
        
        <div className="p-4 bg-white dark:bg-neutral-900 border-t border-neutral-200 dark:border-neutral-700">
          {/* Code length indicator */}
          {codeInput.length > 0 && (
            <div className="mb-2">
              <div className="flex justify-between text-xs text-neutral-500 dark:text-neutral-400 mb-1">
                <span>Code length: {codeInput.length} characters</span>
                <span>{getCodeLengthPercentage()}% of recommended max</span>
              </div>
              <div className="w-full h-1.5 bg-neutral-200 dark:bg-neutral-700 rounded-full overflow-hidden">
                <div 
                  className={`h-full rounded-full ${getCodeLengthColor()}`} 
                  style={{ width: `${getCodeLengthPercentage()}%` }}
                ></div>
              </div>
            </div>
          )}
          
          {/* Warning message for long code */}
          {showCodeLengthWarning && (
            <div className="mb-3 p-2 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded text-sm text-amber-700 dark:text-amber-400">
              <div className="flex items-start">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-5 h-5 mr-2 flex-shrink-0 text-amber-500">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z" />
                </svg>
                <div>
                  <p className="font-medium mb-1">Your code is quite long</p>
                  <p>Long code may be truncated or processed less effectively. Consider:</p>
                  <ul className="list-disc pl-5 mt-1 space-y-0.5">
                    <li>Focusing on a specific section of your code</li>
                    <li>Removing comments or debug statements</li>
                    {codeInput.length > MAX_RECOMMENDED_LENGTH && 
                      <li className="text-red-600 dark:text-red-400 font-medium">Your code exceeds the recommended maximum length</li>
                    }
                  </ul>
                </div>
              </div>
            </div>
          )}
          
          <AnalysisModeSelector activeTab={activeTab} setActiveTab={setActiveTab} />
          
          <Button
            onClick={onSubmit}
            disabled={!codeInput.trim() || isLoading}
            className={`w-full mt-3 py-3 px-4 font-medium rounded-md transition-all duration-200 flex items-center justify-center disabled:opacity-60 disabled:cursor-not-allowed ${
              activeTab === "explain" ? "bg-blue-500 hover:bg-blue-600 text-white shadow-md hover:shadow-blue-200 dark:hover:shadow-blue-900/30" :
              activeTab === "debug" ? "bg-purple-500 hover:bg-purple-600 text-white shadow-md hover:shadow-purple-200 dark:hover:shadow-purple-900/30" :
              activeTab === "document" ? "bg-teal-500 hover:bg-teal-600 text-white shadow-md hover:shadow-teal-200 dark:hover:shadow-teal-900/30" :
              activeTab === "interview" ? "bg-amber-500 hover:bg-amber-600 text-white shadow-md hover:shadow-amber-200 dark:hover:shadow-amber-900/30" :
              "bg-emerald-500 hover:bg-emerald-600 text-white shadow-md hover:shadow-emerald-200 dark:hover:shadow-emerald-900/30"
            }`}
          >
            {isLoading ? (
              <div className="flex items-center">
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Processing...
              </div>
            ) : (
              <div className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-5 h-5 mr-2">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904 9 18.75l-.813-2.846a4.5 4.5 0 0 0-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 0 0 3.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 0 0 3.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 0 0-3.09 3.09ZM18.259 8.715 18 9.75l-.259-1.035a3.375 3.375 0 0 0-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 0 0 2.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 0 0 2.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 0 0-2.456 2.456ZM16.894 20.567 16.5 21.75l-.394-1.183a2.25 2.25 0 0 0-1.423-1.423L13.5 18.75l1.183-.394a2.25 2.25 0 0 0 1.423-1.423l.394-1.183.394 1.183a2.25 2.25 0 0 0 1.423 1.423l1.183.394-1.183.394a2.25 2.25 0 0 0-1.423 1.423Z" />
                </svg>
                Generate AI Response
              </div>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}
