import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const sessions = pgTable("sessions", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  language: text("language").notNull(),
  snippet: text("snippet").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }),
  tags: text("tags").array(),
});

export const insertSessionSchema = createInsertSchema(sessions).pick({
  title: true,
  language: true,
  snippet: true,
  tags: true,
  userId: true,
});

export const histories = pgTable("histories", {
  id: serial("id").primaryKey(),
  snippet: text("snippet").notNull(),
  response: text("response").notNull(),
  language: text("language").notNull(),
  mode: text("mode").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }),
});

export const insertHistorySchema = createInsertSchema(histories).pick({
  snippet: true,
  response: true,
  language: true,
  mode: true,
  userId: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertSession = z.infer<typeof insertSessionSchema>;
export type Session = typeof sessions.$inferSelect;

export type InsertHistory = z.infer<typeof insertHistorySchema>;
export type History = typeof histories.$inferSelect;

// Analyze code request type
export type AnalyzeCodeRequest = {
  code: string;
  language: string;
  mode: string;
};

export const analyzeCodeSchema = z.object({
  code: z.string().min(1, "Code is required"),
  language: z.string().min(1, "Language is required"),
  mode: z.string().min(1, "Analysis mode is required"),
});
