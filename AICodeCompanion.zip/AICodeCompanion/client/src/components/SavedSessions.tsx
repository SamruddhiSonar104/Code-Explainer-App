import React, { useState } from "react";
import { Session } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";

interface SavedSessionsProps {
  sessions: Session[];
  onLoadSession: (session: Session) => void;
}

export default function SavedSessions({ sessions, onLoadSession }: SavedSessionsProps) {
  const [isSaving, setIsSaving] = useState(false);

  const handleSaveCurrentSession = () => {
    // Dispatching a custom event that will be caught by the parent component
    window.dispatchEvent(new CustomEvent('code-companion:save-session'));
  };

  return (
    <>
      <div className="flex items-center justify-between mb-2">
        <h2 className="text-xs font-semibold text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">Saved Sessions</h2>
        <button
          onClick={handleSaveCurrentSession}
          className="text-xs text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300 font-medium"
          disabled={isSaving}
        >
          Save Current
        </button>
      </div>
      <div className="space-y-3">
        {sessions.map((session) => (
          <div key={session.id} className="border border-neutral-200 dark:border-neutral-700 rounded-md overflow-hidden">
            <div
              onClick={() => onLoadSession(session)}
              className="p-2 hover:bg-neutral-50 dark:hover:bg-neutral-800 cursor-pointer"
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-medium text-sm text-neutral-800 dark:text-neutral-200">{session.title}</span>
                <span className="text-xs text-neutral-500 dark:text-neutral-400">
                  {formatDistanceToNow(new Date(session.createdAt), { addSuffix: true })}
                </span>
              </div>
              <div className="text-xs font-mono text-neutral-700 dark:text-neutral-300 truncate">
                {session.snippet.split("\n")[0]}
                {session.snippet.split("\n").length > 1 ? "..." : ""}
              </div>
              <div className="flex gap-1 mt-2">
                {session.tags?.map((tag, i) => (
                  <span key={i} className="text-xs bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 px-2 py-0.5 rounded">
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}
