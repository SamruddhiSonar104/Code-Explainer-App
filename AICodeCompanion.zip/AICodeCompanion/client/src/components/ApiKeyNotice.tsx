import { useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';

interface ApiKeyNoticeProps {
  onRequestApiKey: () => void;
}

export default function ApiKeyNotice({ onRequestApiKey }: ApiKeyNoticeProps) {
  const { toast } = useToast();
  
  // Check API key status when the component mounts
  useEffect(() => {
    const checkApiKey = async () => {
      try {
        const response = await fetch('/api/check-key');
        const data = await response.json();
        
        if (!data.valid) {
          toast({
            title: data.missing ? 'OpenAI API Key Missing' : 'OpenAI API Key Issue',
            description: (
              <div className="flex flex-col space-y-2">
                <p>{data.message || 'The application needs a valid OpenAI API key to function properly.'}</p>
                <button 
                  onClick={onRequestApiKey}
                  className="bg-blue-500 text-white px-3 py-1 rounded text-sm hover:bg-blue-600 transition-colors self-start mt-1"
                >
                  Provide API Key
                </button>
              </div>
            ),
            duration: 15000, // Extended duration
          });
        }
      } catch (error) {
        console.error('Error checking API key:', error);
      }
    };
    
    checkApiKey();
  }, [onRequestApiKey, toast]);
  
  return null; // This is a functional component that doesn't render UI directly
}