import { useState } from "react";
import SessionHistory from "./SessionHistory";
import SavedSessions from "./SavedSessions";
import { History, Session } from "@shared/schema";

interface SidebarProps {
  open: boolean;
  onClose: () => void;
  onToggleDarkMode: () => void;
  darkMode: boolean;
}

export default function Sidebar({ open, onClose, onToggleDarkMode, darkMode }: SidebarProps) {
  const [history, setHistory] = useState<History[]>([]);
  const [savedSessions, setSavedSessions] = useState<Session[]>([
    {
      id: 1,
      title: "React Hooks Example",
      language: "javascript",
      snippet: `useEffect(() => {
  // This runs after every render
  document.title = \`You clicked \${count} times\`;

  return () => {
    // Cleanup function
    console.log('Component unmounted');
  };
}, [count]);`,
      createdAt: new Date(),
      tags: ["React", "Hooks"],
      userId: 1
    },
    {
      id: 2,
      title: "Python List Comprehension",
      language: "python",
      snippet: `numbers = [1, 2, 3, 4, 5]

# Create a new list with squares of each number
squares = [num**2 for num in numbers if num > 2]`,
      createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 1 week ago
      tags: ["Python", "Basics"],
      userId: 1
    }
  ]);

  const handleNewSession = () => {
    // Reset the main interface state
    window.dispatchEvent(new CustomEvent('code-companion:new-session'));
  };

  const clearHistory = () => {
    setHistory([]);
  };

  const loadSession = (session: Session) => {
    window.dispatchEvent(
      new CustomEvent('code-companion:load-session', {
        detail: {
          snippet: session.snippet,
          language: session.language
        }
      })
    );
  };

  const loadHistoryItem = (item: History) => {
    window.dispatchEvent(
      new CustomEvent('code-companion:load-history', {
        detail: {
          snippet: item.snippet,
          response: item.response,
          mode: item.mode,
          language: item.language
        }
      })
    );
  };

  return (
    <aside
      className={`fixed inset-y-0 left-0 z-50 w-64 transform bg-white dark:bg-neutral-900 border-r border-neutral-200 dark:border-neutral-700 transition-transform duration-300 ease-in-out lg:static ${
        open ? "translate-x-0" : "-translate-x-full"
      } lg:translate-x-0`}
    >
      {/* Sidebar Header */}
      <div className="flex items-center justify-between h-16 px-4 border-b border-neutral-200 dark:border-neutral-700 lg:h-[72px]">
        <div className="flex items-center">
          <span className="text-primary-500 text-xl font-semibold mr-1">&lt;/&gt;</span>
          <h1 className="text-xl font-semibold text-neutral-800 dark:text-white">CodeCompanion</h1>
        </div>
        <button
          onClick={onClose}
          className="lg:hidden text-neutral-500 hover:text-neutral-600 dark:text-neutral-400 dark:hover:text-neutral-300"
        >
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-6 h-6">
            <path strokeLinecap="round" strokeLinejoin="round" d="M6 18 18 6M6 6l12 12" />
          </svg>
        </button>
      </div>

      {/* Sidebar Content */}
      <div className="flex flex-col h-[calc(100%-72px)] overflow-y-auto">
        {/* New Session Button */}
        <div className="p-4">
          <button
            onClick={handleNewSession}
            className="w-full flex items-center justify-center px-4 py-2 bg-primary-500 hover:bg-primary-600 text-white font-medium rounded-md transition-colors"
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-5 h-5 mr-2">
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
            </svg>
            New Session
          </button>
        </div>

        {/* Recent History */}
        <div className="px-4 py-2">
          <SessionHistory history={history.slice(0, 3)} onSelectItem={loadHistoryItem} />
        </div>

        {/* Saved Sessions */}
        <div className="px-4 py-2 border-t border-neutral-200 dark:border-neutral-700">
          <SavedSessions sessions={savedSessions} onLoadSession={loadSession} />
        </div>

        {/* App Info */}
        <div className="mt-auto p-4 border-t border-neutral-200 dark:border-neutral-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-neutral-500 dark:text-neutral-400">CodeCompanion v1.0.0</p>
              <p className="text-xs text-neutral-500 dark:text-neutral-400">AI-Powered Coding Assistant</p>
            </div>
            <button onClick={onToggleDarkMode} className="p-2 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800">
              {darkMode ? (
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-5 h-5 text-yellow-400">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v2.25m6.364.386-1.591 1.591M21 12h-2.25m-.386 6.364-1.591-1.591M12 18.75V21m-4.773-4.227-1.591 1.591M5.25 12H3m4.227-4.773L5.636 5.636M15.75 12a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0Z" />
                </svg>
              ) : (
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-5 h-5 text-neutral-700">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M21.752 15.002A9.72 9.72 0 0 1 18 15.75c-5.385 0-9.75-4.365-9.75-9.75 0-1.33.266-2.597.748-3.752A9.753 9.753 0 0 0 3 11.25C3 16.635 7.365 21 12.75 21a9.753 9.753 0 0 0 9.002-5.998Z" />
                </svg>
              )}
            </button>
          </div>
        </div>
      </div>
    </aside>
  );
}
