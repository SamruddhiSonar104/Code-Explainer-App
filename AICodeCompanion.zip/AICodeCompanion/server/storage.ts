import { 
  InsertUser, 
  User, 
  Session, 
  InsertSession, 
  History, 
  InsertHistory,
  users,
  sessions, 
  histories 
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

// modify the interface with any CRUD methods
// you might need
export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Session methods
  getSession(id: number): Promise<Session | undefined>;
  getSessionsByUserId(userId: number): Promise<Session[]>;
  createSession(session: InsertSession): Promise<Session>;
  
  // History methods
  getHistory(id: number): Promise<History | undefined>;
  getHistoryByUserId(userId: number): Promise<History[]>;
  createHistory(history: InsertHistory): Promise<History>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }
  
  // Session methods
  async getSession(id: number): Promise<Session | undefined> {
    const [session] = await db.select().from(sessions).where(eq(sessions.id, id));
    return session || undefined;
  }
  
  async getSessionsByUserId(userId: number): Promise<Session[]> {
    return await db
      .select()
      .from(sessions)
      .where(eq(sessions.userId, userId))
      .orderBy(sessions.createdAt);
  }
  
  async createSession(insertSession: InsertSession): Promise<Session> {
    const [session] = await db
      .insert(sessions)
      .values(insertSession)
      .returning();
    return session;
  }
  
  // History methods
  async getHistory(id: number): Promise<History | undefined> {
    const [history] = await db.select().from(histories).where(eq(histories.id, id));
    return history || undefined;
  }
  
  async getHistoryByUserId(userId: number): Promise<History[]> {
    return await db
      .select()
      .from(histories)
      .where(eq(histories.userId, userId))
      .orderBy(histories.createdAt);
  }
  
  async createHistory(insertHistory: InsertHistory): Promise<History> {
    const [history] = await db
      .insert(histories)
      .values(insertHistory)
      .returning();
    return history;
  }
}

// Create an instance of the storage
export const storage = new DatabaseStorage();

// Add seed data if it doesn't exist
async function seedDatabase() {
  try {
    // Check if we have any users
    const allUsers = await db.select().from(users);
    
    if (allUsers.length === 0) {
      // Create default user
      const [defaultUser] = await db
        .insert(users)
        .values({
          username: "default",
          password: "password",
        })
        .returning();
      
      // Create example sessions
      await db.insert(sessions).values([
        {
          title: "React Hooks Example",
          language: "javascript",
          snippet: `useEffect(() => {
  // This runs after every render
  document.title = \`You clicked \${count} times\`;

  return () => {
    // Cleanup function
    console.log('Component unmounted');
  };
}, [count]);`,
          tags: ["React", "Hooks"],
          userId: defaultUser.id,
        },
        {
          title: "Python List Comprehension",
          language: "python",
          snippet: `numbers = [1, 2, 3, 4, 5]

# Create a new list with squares of each number
squares = [num**2 for num in numbers if num > 2]`,
          tags: ["Python", "Basics"],
          userId: defaultUser.id,
        }
      ]);
      
      console.log('Database seeded with initial data');
    }
  } catch (error) {
    console.error('Error seeding database:', error);
  }
}

// Call this function when the server starts
seedDatabase();
