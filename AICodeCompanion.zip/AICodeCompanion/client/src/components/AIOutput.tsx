import { useState, useEffect, useRef } from "react";
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { oneDark, oneLight } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { useTheme } from "./ThemeProvider";

interface AIOutputProps {
  activeTab: string;
  aiResponse: string;
  isLoading: boolean;
  onCopy: () => void;
}

export default function AIOutput({ activeTab, aiResponse, isLoading, onCopy }: AIOutputProps) {
  const { theme } = useTheme();
  const outputRef = useRef<HTMLDivElement>(null);
  const [headerGradient, setHeaderGradient] = useState<string>("bg-gradient-to-r from-blue-500 to-purple-500");
  
  // Change header gradient based on active tab
  useEffect(() => {
    switch(activeTab) {
      case "explain":
        setHeaderGradient("bg-gradient-to-r from-blue-500 to-indigo-600");
        break;
      case "debug":
        setHeaderGradient("bg-gradient-to-r from-purple-500 to-pink-500");
        break;
      case "document":
        setHeaderGradient("bg-gradient-to-r from-teal-400 to-emerald-500");
        break;
      case "interview":
        setHeaderGradient("bg-gradient-to-r from-amber-400 to-orange-500");
        break;
      case "improve":
        setHeaderGradient("bg-gradient-to-r from-emerald-400 to-green-500");
        break;
      default:
        setHeaderGradient("bg-gradient-to-r from-blue-500 to-purple-500");
    }
  }, [activeTab]);
  
  // Function to highlight code blocks in the AI response
  useEffect(() => {
    if (!isLoading && aiResponse && outputRef.current) {
      // This will handle code highlighting if needed
    }
  }, [aiResponse, isLoading]);

  // Function to handle response rendering, including error messages
  const renderResponse = () => {
    if (!aiResponse) return null;
    
    // Check if this is an error message
    const isErrorMessage = aiResponse.includes('error-message');
    
    return (
      <div 
        className={`prose prose-sm dark:prose-invert max-w-none ${
          isErrorMessage ? 'error-container' : ''
        }`} 
        dangerouslySetInnerHTML={{ __html: aiResponse }} 
      />
    );
  };

  // Get icon and colors based on active tab
  const getTabIcon = () => {
    switch(activeTab) {
      case "explain":
        return (
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-5 h-5">
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 18v-5.25m0 0a6.01 6.01 0 0 0 1.5-.189m-1.5.189a6.01 6.01 0 0 1-1.5-.189m3.75 7.478a12.06 12.06 0 0 1-4.5 0m3.75 2.383a14.406 14.406 0 0 1-3 0M14.25 18v-.192c0-.983.658-1.823 1.508-2.316a7.5 7.5 0 1 0-7.517 0c.85.493 1.509 1.333 1.509 2.316V18" />
          </svg>
        );
      case "debug":
        return (
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-5 h-5">
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 12.75c1.148 0 2.278.08 3.383.237 1.037.146 1.866.966 1.866 2.013 0 3.728-2.35 6.75-5.25 6.75S6.75 18.728 6.75 15c0-1.046.83-1.867 1.866-2.013A24.204 24.204 0 0 1 12 12.75Zm0 0c2.883 0 5.647.508 8.207 1.44a23.91 23.91 0 0 1-1.152 6.06M12 12.75c-2.883 0-5.647.508-8.208 1.44.125 2.104.52 4.136 1.153 6.06M12 12.75a2.25 2.25 0 0 0 2.248-2.354M12 12.75a2.25 2.25 0 0 1-2.248-2.354M12 8.25c.995 0 1.971-.08 2.922-.236.403-.066.74-.358.795-.762a3.778 3.778 0 0 0-.4-2.253M12 8.25c-.995 0-1.97-.08-2.922-.236-.402-.066-.74-.358-.795-.762a3.734 3.734 0 0 1 .4-2.253M12 8.25a2.25 2.25 0 0 0-2.248 2.146M12 8.25a2.25 2.25 0 0 1 2.248 2.146M8.683 5a6.032 6.032 0 0 1-1.155-1.002c.07-.63.27-1.222.574-1.747m.581 2.749A3.75 3.75 0 0 1 15.318 5m0 0c.427-.283.815-.62 1.155-.999a4.471 4.471 0 0 0-.575-1.752M4.921 6a24.048 24.048 0 0 0-.392 3.314c1.668.546 3.416.914 5.223 1.082M19.08 6c.205 1.08.337 2.187.392 3.314a23.882 23.882 0 0 1-5.223 1.082" />
          </svg>
        );
      case "document":
        return (
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-5 h-5">
            <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z" />
          </svg>
        );
      case "interview":
        return (
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-5 h-5">
            <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 8.511c.884.284 1.5 1.128 1.5 2.097v4.286c0 1.136-.847 2.1-1.98 2.193-.34.027-.68.052-1.02.072v3.091l-3-3c-1.354 0-2.694-.055-4.02-.163a2.115 2.115 0 0 1-.825-.242m9.345-8.334a2.126 2.126 0 0 0-.476-.095 48.64 48.64 0 0 0-8.048 0c-1.131.094-1.976 1.057-1.976 2.192v4.286c0 .837.46 1.58 1.155 1.951m9.345-8.334V6.637c0-1.621-1.152-3.026-2.76-3.235A48.455 48.455 0 0 0 11.25 3c-2.115 0-4.198.137-6.24.402-1.608.209-2.76 1.614-2.76 3.235v6.226c0 1.621 1.152 3.026 2.76 3.235.577.075 1.157.14 1.74.194V21l4.155-4.155" />
          </svg>
        );
      case "improve":
        return (
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-5 h-5">
            <path strokeLinecap="round" strokeLinejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 0 1 3 19.875v-6.75ZM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 0 1-1.125-1.125V8.625ZM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 0 1-1.125-1.125V4.125Z" />
          </svg>
        );
      default:
        return (
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-5 h-5">
            <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904 9 18.75l-.813-2.846a4.5 4.5 0 0 0-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 0 0 3.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 0 0 3.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 0 0-3.09 3.09Z" />
          </svg>
        );
    }
  };

  return (
    <div className="w-full md:w-1/2 h-full flex flex-col overflow-hidden">
      {/* Colorful header based on active tab */}
      <div className={`flex items-center justify-between px-4 py-3 ${headerGradient} text-white border-b border-neutral-200 dark:border-neutral-700`}>
        <div className="flex items-center space-x-2">
          {getTabIcon()}
          <span className="font-medium">AI Response</span>
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-white/20 backdrop-blur-sm">
            {activeTab.charAt(0).toUpperCase() + activeTab.slice(1)} Mode
          </span>
        </div>
        
        <div className="flex items-center space-x-2">
          <button
            onClick={onCopy}
            className={`p-1.5 rounded-md bg-white/20 hover:bg-white/30 backdrop-blur-sm transition-all duration-200 ${
              !aiResponse ? "opacity-50 cursor-not-allowed" : "cursor-pointer"
            }`}
            disabled={!aiResponse}
            title="Copy response"
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-4 h-4">
              <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 17.25v3.375c0 .621-.504 1.125-1.125 1.125h-9.75a1.125 1.125 0 0 1-1.125-1.125V7.875c0-.621.504-1.125 1.125-1.125H6.75a9.06 9.06 0 0 1 1.5.124m7.5 10.376h3.375c.621 0 1.125-.504 1.125-1.125V11.25c0-4.46-3.243-8.161-7.5-8.876a9.06 9.06 0 0 0-1.5-.124H9.375c-.621 0-1.125.504-1.125 1.125v3.5m7.5 10.375H9.375a1.125 1.125 0 0 1-1.125-1.125v-9.25m12 6.625v-1.875a3.375 3.375 0 0 0-3.375-3.375h-1.5a1.125 1.125 0 0 1-1.125-1.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H9.75" />
            </svg>
          </button>
          <button
            className={`p-1.5 rounded-md bg-white/20 hover:bg-white/30 backdrop-blur-sm transition-all duration-200 ${
              !aiResponse ? "opacity-50 cursor-not-allowed" : "cursor-pointer"
            }`}
            disabled={!aiResponse}
            title="Share response"
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-4 h-4">
              <path strokeLinecap="round" strokeLinejoin="round" d="M7.217 10.907a2.25 2.25 0 1 0 0 2.186m0-2.186c.18.324.283.696.283 1.093s-.103.77-.283 1.093m0-2.186 9.566-5.314m-9.566 7.5 9.566 5.314m0 0a2.25 2.25 0 1 0 3.935-2.186 2.25 2.25 0 0 0-3.935 2.186Z" />
            </svg>
          </button>
        </div>
      </div>
      
      {/* Response area with glowing effect based on the active tab */}
      <div 
        className={`flex-1 overflow-auto p-5 bg-white/50 dark:bg-neutral-800/50 backdrop-blur-sm ${
          aiResponse ? (
            activeTab === "explain" ? "shadow-[inset_0_0_40px_rgba(59,130,246,0.1)]" : 
            activeTab === "debug" ? "shadow-[inset_0_0_40px_rgba(168,85,247,0.1)]" :
            activeTab === "document" ? "shadow-[inset_0_0_40px_rgba(20,184,166,0.1)]" :
            activeTab === "interview" ? "shadow-[inset_0_0_40px_rgba(245,158,11,0.1)]" :
            "shadow-[inset_0_0_40px_rgba(16,185,129,0.1)]"
          ) : ""
        }`} 
        ref={outputRef}
      >
        {isLoading ? (
          <div className="flex flex-col items-center justify-center h-full">
            <div className={`p-8 rounded-full ${
              activeTab === "explain" ? "bg-blue-500/10" : 
              activeTab === "debug" ? "bg-purple-500/10" :
              activeTab === "document" ? "bg-teal-500/10" :
              activeTab === "interview" ? "bg-amber-500/10" :
              "bg-emerald-500/10"
            } mb-4`}>
              <div className={`flex items-center justify-center relative w-16 h-16 ${
                activeTab === "explain" ? "text-blue-500" : 
                activeTab === "debug" ? "text-purple-500" :
                activeTab === "document" ? "text-teal-500" :
                activeTab === "interview" ? "text-amber-500" :
                "text-emerald-500"
              }`}>
                {/* Animated rings */}
                <div className="absolute inset-0 rounded-full animate-ping opacity-20 border-4 border-current"></div>
                <div className="absolute inset-2 rounded-full animate-pulse opacity-40 border-4 border-current"></div>
                {/* Icon in center */}
                <div className="z-10 transform scale-150">
                  {getTabIcon()}
                </div>
              </div>
            </div>
            <p className={`text-lg font-medium ${
              activeTab === "explain" ? "text-blue-600 dark:text-blue-400" : 
              activeTab === "debug" ? "text-purple-600 dark:text-purple-400" :
              activeTab === "document" ? "text-teal-600 dark:text-teal-400" :
              activeTab === "interview" ? "text-amber-600 dark:text-amber-400" :
              "text-emerald-600 dark:text-emerald-400"
            }`}>Analyzing your code...</p>
            <p className="text-neutral-500 dark:text-neutral-400 text-sm mt-2">The AI is processing your request</p>
          </div>
        ) : !aiResponse ? (
          <div className="flex flex-col items-center justify-center h-full">
            <div className={`p-6 rounded-full mb-4 ${
              activeTab === "explain" ? "bg-blue-500/10" : 
              activeTab === "debug" ? "bg-purple-500/10" :
              activeTab === "document" ? "bg-teal-500/10" :
              activeTab === "interview" ? "bg-amber-500/10" :
              "bg-emerald-500/10"
            }`}>
              <div className={`w-12 h-12 ${
                activeTab === "explain" ? "text-blue-500" : 
                activeTab === "debug" ? "text-purple-500" :
                activeTab === "document" ? "text-teal-500" :
                activeTab === "interview" ? "text-amber-500" :
                "text-emerald-500"
              }`}>
                {getTabIcon()}
              </div>
            </div>
            <div className="text-center max-w-sm space-y-2">
              <h3 className={`text-xl font-semibold ${
                activeTab === "explain" ? "text-blue-600 dark:text-blue-400" : 
                activeTab === "debug" ? "text-purple-600 dark:text-purple-400" :
                activeTab === "document" ? "text-teal-600 dark:text-teal-400" :
                activeTab === "interview" ? "text-amber-600 dark:text-amber-400" :
                "text-emerald-600 dark:text-emerald-400"
              }`}>
                Ready to {activeTab} your code
              </h3>
              <p className="text-neutral-600 dark:text-neutral-300">
                {activeTab === "explain" ? "Get a clear, step-by-step explanation of what your code does." : 
                 activeTab === "debug" ? "Find and fix bugs, errors, and edge cases in your code." :
                 activeTab === "document" ? "Generate comprehensive documentation for your code." :
                 activeTab === "interview" ? "Practice with interview questions related to your code." :
                 "Receive suggestions on how to improve and optimize your code."}
              </p>
              <p className="text-neutral-500 dark:text-neutral-400 text-sm">
                Paste your code in the editor and click "Generate AI Response"
              </p>
            </div>
          </div>
        ) : (
          <div className={`rounded-lg border-l-4 p-6 ${
            activeTab === "explain" ? "border-blue-500" : 
            activeTab === "debug" ? "border-purple-500" :
            activeTab === "document" ? "border-teal-500" :
            activeTab === "interview" ? "border-amber-500" :
            "border-emerald-500"
          } bg-white dark:bg-neutral-900 shadow-md`}>
            {renderResponse()}
          </div>
        )}
      </div>
    </div>
  );
}
