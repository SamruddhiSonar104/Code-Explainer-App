import { useState, useEffect } from 'react';
import { useToast } from './use-toast';

type ApiKeyStatus = 'unknown' | 'valid' | 'invalid' | 'missing';

export function useApiKey() {
  const [apiKeyStatus, setApiKeyStatus] = useState<ApiKeyStatus>('unknown');
  const [isChecking, setIsChecking] = useState(false);
  const { toast } = useToast();
  
  // Function to check if the API key is valid
  const checkApiKey = async () => {
    setIsChecking(true);
    try {
      // Make a simple request to the /api/check-key endpoint (we'll create this later)
      const response = await fetch('/api/check-key');
      const data = await response.json();
      
      if (data.valid) {
        setApiKeyStatus('valid');
      } else {
        // If key is explicitly missing or invalid, set the appropriate status
        setApiKeyStatus(data.missing ? 'missing' : 'invalid');
        
        // Show a toast notification
        toast({
          title: data.missing ? 'OpenAI API Key Missing' : 'OpenAI API Key Invalid',
          description: data.message || 'Please check your API key settings.',
          variant: 'destructive',
        });
      }
    } catch (error) {
      console.error("Error checking API key:", error);
      setApiKeyStatus('unknown');
    } finally {
      setIsChecking(false);
    }
  };
  
  // Function to prompt user to provide their API key
  const promptForApiKey = () => {
    const apiKey = prompt('Please enter your OpenAI API key:');
    if (apiKey) {
      saveApiKey(apiKey);
    }
  };
  
  // Function to save the API key (this would typically store it on the server)
  const saveApiKey = async (apiKey: string) => {
    try {
      const response = await fetch('/api/set-key', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ apiKey }),
      });
      
      const data = await response.json();
      
      if (data.success) {
        setApiKeyStatus('valid');
        toast({
          title: 'API Key Saved',
          description: 'Your OpenAI API key has been saved successfully.',
        });
      } else {
        setApiKeyStatus('invalid');
        toast({
          title: 'Invalid API Key',
          description: data.message || 'The provided API key is invalid.',
          variant: 'destructive',
        });
      }
    } catch (error) {
      console.error("Error saving API key:", error);
      toast({
        title: 'Error Saving API Key',
        description: 'There was an error saving your API key. Please try again.',
        variant: 'destructive',
      });
    }
  };
  
  // Check the API key status when the component mounts
  useEffect(() => {
    checkApiKey();
  }, []);
  
  return {
    apiKeyStatus,
    isChecking,
    checkApiKey,
    promptForApiKey,
  };
}