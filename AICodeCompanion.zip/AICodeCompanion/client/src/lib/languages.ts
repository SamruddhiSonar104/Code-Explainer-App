import { useState } from "react";

export interface Language {
  value: string;
  label: string;
}

export const supportedLanguages: Language[] = [
  { value: "javascript", label: "JavaScript" },
  { value: "python", label: "Python" },
  { value: "java", label: "Java" },
  { value: "csharp", label: "C#" },
  { value: "cpp", label: "C++" },
  { value: "go", label: "Go" },
  { value: "ruby", label: "Ruby" },
  { value: "php", label: "PHP" },
  { value: "swift", label: "Swift" },
  { value: "typescript", label: "TypeScript" },
  { value: "rust", label: "Rust" },
  { value: "kotlin", label: "Kotlin" },
  { value: "scala", label: "Scala" },
  { value: "html", label: "HTML" },
  { value: "css", label: "CSS" },
  { value: "sql", label: "SQL" },
];

export function useLanguages() {
  // Default to JavaScript
  const [selectedLanguage, setSelectedLanguage] = useState("javascript");
  
  return {
    languages: supportedLanguages,
    selectedLanguage,
    setSelectedLanguage,
  };
}
