import OpenAI from "openai";
import { getPromptTemplate } from "../client/src/lib/prompt-templates";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY || "default_key" });

// Create a mapping of modes to system prompts
const modeSystemPrompts: Record<string, string> = {
  explain: "You are an expert programming tutor specializing in explaining code in a clear, step-by-step manner for beginners. Break down complex concepts, focus on fundamentals, and use analogies where appropriate. Format your response with HTML for better readability, using <h3>, <p>, <ol>, <ul>, <li>, <code>, and other tags as needed. Include syntax highlighting when showing code snippets.",
  
  debug: "You are a senior software engineer with expertise in debugging code. Identify potential bugs, logic errors, edge cases, and performance issues in the provided code. Explain why each issue is problematic and provide a corrected version. Format your response with HTML for better readability, using <h3>, <p>, <div> with appropriate classes for warnings and error messages.",
  
  document: "You are a documentation specialist who creates clear, comprehensive documentation for code. Analyze the provided code and generate professional documentation that includes description, parameters, return values, usage examples, and notes about edge cases or limitations. Format your response with HTML for better readability, using semantic tags to clearly structure the documentation.",
  
  interview: "You are a technical interviewer assessing a candidate's knowledge of the provided code. Generate 3-5 interview questions that test understanding of the code, its concepts, potential optimizations, and trade-offs. For each question, include what would be considered an ideal answer. Format your response with HTML for better readability.",
  
  improve: "You are a code optimization expert who suggests improvements to existing code. Analyze the provided code and suggest realistic improvements for readability, performance, maintainability, or robustness. Provide concrete code examples of your improvements. Format your response with HTML for better readability, using semantic tags to clearly structure your suggestions."
};

// Demo mode responses for each analysis type
const demoResponses: Record<string, Record<string, string>> = {
  javascript: {
    explain: `<div>
      <h3>Code Explanation</h3>
      <p>This code defines a simple function called <code>calculateSum</code> that takes an array of numbers and returns their sum.</p>
      <h4>Step-by-Step Breakdown:</h4>
      <ol>
        <li>The function declaration <code>function calculateSum(numbers)</code> creates a function that accepts one parameter: an array called <code>numbers</code>.</li>
        <li>The variable <code>total</code> is initialized to 0, which will store our running sum.</li>
        <li>A for loop iterates through each element in the array:</li>
        <ul>
          <li>Starting with <code>i = 0</code> (first element)</li>
          <li>Continuing as long as <code>i</code> is less than the array length</li>
          <li>Incrementing <code>i</code> after each iteration</li>
        </ul>
        <li>For each element, its value is added to the <code>total</code> variable.</li>
        <li>After processing all elements, the function returns the final sum.</li>
      </ol>
      <p>This is an example of an <em>iterative approach</em> to summing an array, which has a time complexity of O(n) where n is the length of the array.</p>
      <h4>Example Usage:</h4>
      <pre><code>const myNumbers = [5, 10, 15, 20];
const result = calculateSum(myNumbers);
console.log(result); // Outputs: 50</code></pre>
    </div>`,
    
    debug: `<div>
      <h3>Code Analysis & Debugging</h3>
      <p>After reviewing your function, I've identified several potential issues:</p>
      
      <div class="issue-block">
        <h4>1. No Input Validation</h4>
        <p>The function doesn't check if the input is actually an array or if the elements are numbers. This could lead to unexpected behavior.</p>
        <pre><code class="error-code">// Current code has no validation
function calculateSum(numbers) {
  let total = 0;
  for (let i = 0; i < numbers.length; i++) {
    total += numbers[i];
  }
  return total;
}</code></pre>
        
        <pre><code class="fixed-code">// Improved code with validation
function calculateSum(numbers) {
  // Check if input is an array
  if (!Array.isArray(numbers)) {
    throw new TypeError('Input must be an array');
  }
  
  let total = 0;
  for (let i = 0; i < numbers.length; i++) {
    // Ensure element is a number
    if (typeof numbers[i] !== 'number' || isNaN(numbers[i])) {
      throw new TypeError('All elements must be valid numbers');
    }
    total += numbers[i];
  }
  return total;
}</code></pre>
      </div>
      
      <div class="issue-block">
        <h4>2. Potential Performance Improvement</h4>
        <p>For modern JavaScript, using array methods like reduce is often more concise and expressive:</p>
        <pre><code class="improved-code">// Using modern JavaScript features
function calculateSum(numbers) {
  if (!Array.isArray(numbers)) {
    throw new TypeError('Input must be an array');
  }
  
  return numbers.reduce((sum, num) => {
    if (typeof num !== 'number' || isNaN(num)) {
      throw new TypeError('All elements must be valid numbers');
    }
    return sum + num;
  }, 0);
}</code></pre>
      </div>
      
      <div class="issue-block">
        <h4>3. Edge Cases</h4>
        <p>The function doesn't handle these edge cases:</p>
        <ul>
          <li>Empty array (currently returns 0, which might be acceptable)</li>
          <li>Very large arrays that might cause a stack overflow (the current implementation is better for this than recursion)</li>
          <li>Handling potential integer overflow with extremely large numbers</li>
        </ul>
      </div>
    </div>`,
    
    document: `<div class="documentation">
      <h2>Function: calculateSum</h2>
      
      <section class="description">
        <h3>Description</h3>
        <p>Calculates the sum of all numbers in an array.</p>
      </section>
      
      <section class="parameters">
        <h3>Parameters</h3>
        <table>
          <tr>
            <th>Name</th>
            <th>Type</th>
            <th>Description</th>
            <th>Required</th>
          </tr>
          <tr>
            <td>numbers</td>
            <td>Array&lt;number&gt;</td>
            <td>The array of numbers to sum</td>
            <td>Yes</td>
          </tr>
        </table>
      </section>
      
      <section class="returns">
        <h3>Returns</h3>
        <p><strong>Type:</strong> number</p>
        <p><strong>Description:</strong> The sum of all numbers in the input array</p>
      </section>
      
      <section class="examples">
        <h3>Examples</h3>
        <pre><code>// Basic usage
const result1 = calculateSum([1, 2, 3, 4, 5]);
console.log(result1); // Output: 15

// Empty array
const result2 = calculateSum([]);
console.log(result2); // Output: 0

// Negative numbers
const result3 = calculateSum([-5, 10, -15, 20]);
console.log(result3); // Output: 10</code></pre>
      </section>
      
      <section class="notes">
        <h3>Notes</h3>
        <ul>
          <li>The function assumes all elements in the array are valid numbers</li>
          <li>No input validation is performed</li>
          <li>For large arrays, consider using more efficient methods like reduce</li>
          <li>Time Complexity: O(n) where n is the length of the input array</li>
          <li>Space Complexity: O(1) as only a single variable is used regardless of input size</li>
        </ul>
      </section>
    </div>`
  }
};

// Helper function to identify and handle specific API errors
function handleApiError(error: any): string {
  if (error.status === 429) {
    if (error.error?.type === 'insufficient_quota') {
      return "Your OpenAI API key has exceeded its quota. Please check your billing details or use a different API key.";
    }
    return "Too many requests to the OpenAI API. Please try again later.";
  }
  
  if (error.status === 400) {
    if (error.error?.code === 'context_length_exceeded') {
      return "The code is too long for the AI to process. Please shorten your code or break it into smaller chunks.";
    }
    return "The AI had trouble processing your request. Try simplifying your code or removing any special characters.";
  }
  
  if (!process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY === "default_key") {
    return "No valid OpenAI API key found. Please add your API key in the environment variables to use this feature.";
  }
  
  return "An error occurred while analyzing your code. Please try again later.";
}

// Helper to clean and preprocess the code
function preprocessCode(code: string, maxLength: number = 8000): string {
  // If code is too long, trim it and add a note
  if (code.length > maxLength) {
    const firstPart = Math.floor(maxLength * 0.7); // Use 70% for the first part
    const lastPart = maxLength - firstPart - 100; // Reserve 100 chars for the message
    
    return code.substring(0, firstPart) + 
           "\n\n// ... [code truncated due to length constraints] ...\n// Showing first and last parts of the code\n// Total original length: " + 
           code.length + " characters\n\n" + 
           code.substring(code.length - lastPart);
  }
  
  // Remove potentially problematic characters or sequences that might cause issues
  return code
    .replace(/^\s+|\s+$/g, '') // Trim excess whitespace at start/end
    .replace(/\t/g, '  ');     // Replace tabs with spaces
}

// Check if we should use demo mode (no API key or development environment)
function shouldUseDemoMode(): boolean {
  return (
    !process.env.OPENAI_API_KEY || 
    process.env.OPENAI_API_KEY === "default_key" || 
    process.env.USE_DEMO_MODE === "true"
  );
}

export async function analyzeCode(code: string, language: string, mode: string): Promise<string> {
  try {
    // Check if we should use demo mode
    if (shouldUseDemoMode()) {
      console.log("Using demo mode for code analysis");
      
      // Check if we have a demo response for this language and mode
      if (demoResponses[language]?.[mode]) {
        return demoResponses[language][mode];
      } else if (demoResponses.javascript[mode]) {
        // Fall back to JavaScript if the specific language isn't supported in demo mode
        return demoResponses.javascript[mode];
      }
      
      // Generic fallback if no demo response is available
      return `<div>
        <h3>Demo Mode - ${mode.charAt(0).toUpperCase() + mode.slice(1)} Analysis</h3>
        <p>This is a demo response. In the full version with an API key, you would receive a detailed analysis of your code here.</p>
        <p>Your code (${language}):</p>
        <pre><code>${code.substring(0, 200)}${code.length > 200 ? '...' : ''}</code></pre>
        <p>To get actual AI analysis, please add a valid OpenAI API key.</p>
      </div>`;
    }
    
    // Regular API-based code analysis
    // Preprocess the code
    const processedCode = preprocessCode(code);
    
    // Get the appropriate prompt template for the selected mode
    const promptTemplate = getPromptTemplate(mode);
    const systemPrompt = modeSystemPrompts[mode] || modeSystemPrompts.explain;
    
    // Call the OpenAI API
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: systemPrompt
        },
        {
          role: "user",
          content: `${promptTemplate}\n\n\`\`\`${language}\n${processedCode}\n\`\`\``
        }
      ],
      temperature: 0.7,
    });

    // Return the response
    return response.choices[0].message.content || "Sorry, I couldn't analyze the code.";
  } catch (error) {
    console.error("Error calling OpenAI API:", error);
    
    // If we encounter an API error, switch to demo mode
    if (error.status === 429 || error.status === 401) {
      console.log("API error encountered, switching to demo mode");
      
      // Set environment variable to use demo mode for future requests
      process.env.USE_DEMO_MODE = "true";
      
      // Call the function again, which will now use demo mode
      return analyzeCode(code, language, mode);
    }
    
    // Format the error message with HTML for display in the UI
    const errorMessage = handleApiError(error);
    return `<div class='error-message'>
      <h3>Error Analyzing Code</h3>
      <p>${errorMessage}</p>
      <p>If you're trying to analyze a large piece of code, consider:</p>
      <ul>
        <li>Breaking it into smaller, focused sections</li>
        <li>Removing unnecessary comments or debugging code</li>
        <li>Focusing on the specific parts you need help with</li>
      </ul>
      <p>You can still use the app in demo mode to see how it works.</p>
    </div>`;
  }
}
