import express, { type Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { analyzeCode } from "./openai";
import { analyzeCodeSchema } from "@shared/schema";
import { ZodError } from "zod";
import OpenAI from "openai";

export async function registerRoutes(app: Express): Promise<Server> {
  // API endpoint for analyzing code
  app.post("/api/analyze", async (req: Request, res: Response) => {
    try {
      // Validate the request body
      const { code, language, mode } = analyzeCodeSchema.parse(req.body);
      
      // Call the OpenAI API to analyze the code
      const response = await analyzeCode(code, language, mode);
      
      // Check if the response is an error message (containing error-message class)
      const isErrorResponse = response.includes('error-message');
      
      if (!isErrorResponse) {
        // Only save successful analyses to history
        try {
          await storage.createHistory({
            snippet: code,
            response: response,
            language: language,
            mode: mode,
            userId: 1, // Default user ID for demo
          });
        } catch (historyError) {
          console.error("Error saving to history:", historyError);
          // Continue even if history save fails
        }
      }
      
      // Return the response (which might be an error message in HTML format)
      return res.json({ response });
    } catch (error: any) {
      console.error("Error analyzing code:", error);
      
      if (error instanceof ZodError) {
        return res.status(400).json({
          message: "Invalid request data",
          errors: error.errors,
        });
      }
      
      // Craft a user-friendly error message
      let errorMessage = "Failed to analyze code";
      if (error?.status === 429) {
        errorMessage = "API rate limit exceeded. Please try again later or check your API key quota.";
      } else if (error?.error?.type === 'insufficient_quota') {
        errorMessage = "Your API key has exceeded its quota. Please check your billing details.";
      } else if (error?.error?.code === 'context_length_exceeded') {
        errorMessage = "The code is too long for analysis. Please break it into smaller chunks.";
      }
      
      return res.status(error?.status || 500).json({
        message: errorMessage,
        error: error instanceof Error ? error.message : "Unknown error",
      });
    }
  });

  // API endpoint for getting session history
  app.get("/api/history", async (req: Request, res: Response) => {
    try {
      const userId = 1; // Default user ID for demo
      const history = await storage.getHistoryByUserId(userId);
      return res.json(history);
    } catch (error: any) {
      console.error("Error fetching history:", error);
      return res.status(500).json({
        message: "Failed to fetch history",
        error: error instanceof Error ? error.message : "Unknown error",
      });
    }
  });

  // API endpoint for saving a session
  app.post("/api/sessions", async (req: Request, res: Response) => {
    try {
      const { title, language, snippet, tags } = req.body;
      const userId = 1; // Default user ID for demo
      
      const session = await storage.createSession({
        title,
        language,
        snippet,
        tags,
        userId,
      });
      
      return res.json(session);
    } catch (error: any) {
      console.error("Error saving session:", error);
      return res.status(500).json({
        message: "Failed to save session",
        error: error instanceof Error ? error.message : "Unknown error",
      });
    }
  });

  // API endpoint for getting saved sessions
  app.get("/api/sessions", async (req: Request, res: Response) => {
    try {
      const userId = 1; // Default user ID for demo
      const sessions = await storage.getSessionsByUserId(userId);
      return res.json(sessions);
    } catch (error: any) {
      console.error("Error fetching sessions:", error);
      return res.status(500).json({
        message: "Failed to fetch sessions",
        error: error instanceof Error ? error.message : "Unknown error",
      });
    }
  });
  
  // API endpoint to check if OpenAI API key is valid
  app.get("/api/check-key", async (req: Request, res: Response) => {
    try {
      const apiKey = process.env.OPENAI_API_KEY;
      
      // Check if API key exists
      if (!apiKey || apiKey === "default_key") {
        return res.json({
          valid: false,
          missing: true,
          message: "OpenAI API key is not set.",
        });
      }
      
      // For now, just check if the key exists and has valid format
      // This avoids making unnecessary API calls that might hit rate limits
      if (apiKey && apiKey.length >= 30 && apiKey.startsWith('sk-')) {
        return res.json({
          valid: true,
          message: "API key is present and has valid format.",
        });
      }
      
      return res.json({
        valid: false,
        missing: false,
        message: "API key has invalid format. It should start with 'sk-' and be at least 30 characters.",
      });
    } catch (error: any) {
      console.error("Error checking API key:", error);
      
      // Check for common API key errors
      if (error?.status === 401) {
        return res.json({
          valid: false,
          missing: false,
          message: "Invalid API key provided.",
        });
      } else if (error?.status === 429 || error?.error?.type === 'insufficient_quota') {
        return res.json({
          valid: false,
          missing: false,
          message: "API key has exceeded its rate limit or quota.",
        });
      }
      
      return res.json({
        valid: false,
        missing: false,
        message: "Error validating API key. Please try again.",
      });
    }
  });
  
  // API endpoint to set the OpenAI API key - Note: In a real app, this should use environment variables
  // or a secure secret storage service rather than keeping it in memory
  app.post("/api/set-key", async (req: Request, res: Response) => {
    try {
      const { apiKey } = req.body;
      
      if (!apiKey || typeof apiKey !== 'string' || apiKey.trim().length < 10) {
        return res.status(400).json({
          success: false,
          message: "Invalid API key format. Please provide a valid OpenAI API key."
        });
      }
      
      const trimmedKey = apiKey.trim();
      
      // Perform basic validation - OpenAI keys start with 'sk-' and are 
      // fairly long. This doesn't guarantee the key is valid but catches
      // obvious formatting issues without making an API call.
      if (!trimmedKey.startsWith('sk-') || trimmedKey.length < 30) {
        return res.status(400).json({
          success: false,
          message: "Invalid API key format. OpenAI keys should start with 'sk-' and be at least 30 characters."
        });
      }
      
      // In a real application, you would save this to a secure storage
      // For this demo, we're using dotenv to temporarily apply it to the current environment
      process.env.OPENAI_API_KEY = trimmedKey;
      
      // We're skipping the actual API call to avoid hitting rate limits
      // In a production app, you'd want to validate the key is actually working
      return res.json({
        success: true,
        message: "API key saved successfully."
      });
    } catch (error: any) {
      console.error("Error setting API key:", error);
      return res.status(500).json({
        success: false,
        message: "An error occurred while setting the API key."
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
