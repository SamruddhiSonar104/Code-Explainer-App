import { useState, useEffect } from "react";
import Layout from "@/components/Layout";
import CodeInput from "@/components/CodeInput";
import AIOutput from "@/components/AIOutput";
import ApiKeyNotice from "@/components/ApiKeyNotice";
import { useCodeAnalysis } from "@/hooks/use-code-analysis";
import { supportedLanguages } from "@/lib/languages";
import { getPromptTemplate } from "@/lib/prompt-templates";
import { useToast } from "@/hooks/use-toast";

export default function HomePage() {
  const [codeInput, setCodeInput] = useState("");
  const [selectedLanguage, setSelectedLanguage] = useState("javascript");
  const [activeTab, setActiveTab] = useState("explain");
  const [aiResponse, setAiResponse] = useState("");
  const { analyzeCode, isLoading } = useCodeAnalysis();
  const { toast } = useToast();

  // Handle new session event
  useEffect(() => {
    const handleNewSession = () => {
      setCodeInput("");
      setAiResponse("");
      setActiveTab("explain");
    };

    const handleLoadSession = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      if (detail) {
        setCodeInput(detail.snippet || "");
        setSelectedLanguage(detail.language || "javascript");
        if (detail.response) {
          setAiResponse(detail.response);
        }
        if (detail.mode) {
          setActiveTab(detail.mode);
        }
      }
    };

    window.addEventListener("code-companion:new-session", handleNewSession);
    window.addEventListener("code-companion:load-session", handleLoadSession);
    window.addEventListener("code-companion:load-history", handleLoadSession);

    return () => {
      window.removeEventListener("code-companion:new-session", handleNewSession);
      window.removeEventListener("code-companion:load-session", handleLoadSession);
      window.removeEventListener("code-companion:load-history", handleLoadSession);
    };
  }, []);

  const handleSubmit = async () => {
    if (!codeInput.trim()) {
      toast({
        title: "Error",
        description: "Please enter some code to analyze",
        variant: "destructive",
      });
      return;
    }

    const promptTemplate = getPromptTemplate(activeTab);
    const response = await analyzeCode({
      code: codeInput,
      language: selectedLanguage,
      mode: activeTab,
    });

    setAiResponse(response);
  };

  const handleCopyResponse = () => {
    // Create a temporary div to hold HTML content for copying
    const tempDiv = document.createElement("div");
    tempDiv.innerHTML = aiResponse;
    
    // Get the text content (strips HTML tags)
    const textContent = tempDiv.textContent || tempDiv.innerText || "";
    
    navigator.clipboard.writeText(textContent);
    
    toast({
      title: "Copied to clipboard",
      description: "The AI response has been copied to your clipboard",
    });
  };

  // Function to prompt user for API key
  const promptForApiKey = () => {
    const apiKey = prompt("Please enter your OpenAI API key to use the application:");
    if (apiKey) {
      // Send the key to the server to be saved
      fetch('/api/set-key', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ apiKey }),
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          toast({
            title: "API Key Saved",
            description: "Your OpenAI API key has been saved successfully. You can now analyze code.",
          });
          // Reload the page to apply the new key
          window.location.reload();
        } else {
          toast({
            title: "Error Saving API Key",
            description: data.message || "There was an error saving your API key. Please try again.",
            variant: "destructive",
          });
        }
      })
      .catch(error => {
        console.error("Error saving API key:", error);
        toast({
          title: "Error",
          description: "There was an error connecting to the server. Please try again.",
          variant: "destructive",
        });
      });
    }
  };

  return (
    <Layout>
      {/* API Key Notice that will display a toast if there's an API key issue */}
      <ApiKeyNotice onRequestApiKey={promptForApiKey} />
      
      <div className="flex-1 flex flex-col md:flex-row h-[calc(100vh-4.5rem)] lg:h-[calc(100vh-72px)] overflow-hidden">
        <CodeInput
          codeInput={codeInput}
          setCodeInput={setCodeInput}
          selectedLanguage={selectedLanguage}
          setSelectedLanguage={setSelectedLanguage}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          onSubmit={handleSubmit}
          isLoading={isLoading}
        />
        <AIOutput
          activeTab={activeTab}
          aiResponse={aiResponse}
          isLoading={isLoading}
          onCopy={handleCopyResponse}
        />
      </div>
    </Layout>
  );
}
