import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export interface CodeAnalysisParams {
  code: string;
  language: string;
  mode: string;
}

export interface AnalysisResult {
  response: string;
}

export function useCodeAnalysis() {
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const { toast } = useToast();

  const analyzeCode = async ({ code, language, mode }: CodeAnalysisParams): Promise<string> => {
    if (!code.trim()) {
      toast({
        title: "Error",
        description: "Please enter some code to analyze",
        variant: "destructive",
      });
      return "";
    }

    setIsLoading(true);
    setResult(null);

    try {
      const response = await apiRequest("POST", "/api/analyze", {
        code,
        language,
        mode,
      });

      const data = await response.json();
      setResult(data.response);
      return data.response;
    } catch (error) {
      console.error("Failed to analyze code:", error);
      toast({
        title: "Error analyzing code",
        description: error instanceof Error ? error.message : "Unknown error occurred",
        variant: "destructive",
      });
      return "";
    } finally {
      setIsLoading(false);
    }
  };

  const reset = () => {
    setResult(null);
  };

  return {
    analyzeCode,
    isLoading,
    result,
    reset,
  };
}
