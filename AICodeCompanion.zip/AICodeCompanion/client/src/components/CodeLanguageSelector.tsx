import { useState } from "react";
import { Language } from "@/lib/languages";

interface CodeLanguageSelectorProps {
  selectedLanguage: string;
  setSelectedLanguage: (language: string) => void;
  languages: Language[];
}

export default function CodeLanguageSelector({
  selectedLanguage,
  setSelectedLanguage,
  languages,
}: CodeLanguageSelectorProps) {
  const [showLanguageSelector, setShowLanguageSelector] = useState(false);

  const getLanguageLabel = (value: string): string => {
    return languages.find((l) => l.value === value)?.label || "Language";
  };

  return (
    <div className="relative" onBlur={() => setTimeout(() => setShowLanguageSelector(false), 100)}>
      <button
        onClick={() => setShowLanguageSelector(!showLanguageSelector)}
        className="flex items-center text-sm font-medium text-neutral-700 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-white"
      >
        <span>{getLanguageLabel(selectedLanguage)}</span>
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-4 h-4 ml-1">
          <path strokeLinecap="round" strokeLinejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5" />
        </svg>
      </button>
      {showLanguageSelector && (
        <div className="absolute left-0 z-10 mt-2 w-40 origin-top-left rounded-md bg-white dark:bg-neutral-800 shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
          <div className="py-1">
            {languages.map((language) => (
              <a
                key={language.value}
                onClick={(e) => {
                  e.preventDefault();
                  setSelectedLanguage(language.value);
                  setShowLanguageSelector(false);
                }}
                href="#"
                className={`text-sm block px-4 py-2 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-700 ${
                  selectedLanguage === language.value ? "bg-neutral-100 dark:bg-neutral-700" : ""
                }`}
              >
                {language.label}
              </a>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
